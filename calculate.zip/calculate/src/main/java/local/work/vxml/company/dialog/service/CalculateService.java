package local.work.vxml.company.dialog.service;

import local.work.vxml.company.dialog.models.Order;
import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;

import java.sql.*;

public class CalculateService {
    private final static Logger LOGGER = Logger.getLogger(CalculateService.class);
    private final BasicDataSource companyDataSource;
    private long currentCallHistoryId;

    public CalculateService(BasicDataSource companyDataSource) {
        this.companyDataSource = companyDataSource;
    }

    public void addOrderToCallHistoryTable(int order_id) {
        LOGGER.info("ADD ORDER ID TO CALL HISTORY");
        try (Connection connection = companyDataSource.getConnection();
             PreparedStatement st = connection.prepareStatement("INSERT INTO call_history (order_id, callid) VALUES (?, ?)",
                     Statement.RETURN_GENERATED_KEYS)) {
            st.setInt(1, order_id);
            st.setInt(1, (int) currentCallHistoryId);
            st.executeUpdate();
            try (ResultSet generatedKeys = st.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    currentCallHistoryId = generatedKeys.getLong(1);
                    LOGGER.info("CURRENT CALL_HISTORY_ID " + currentCallHistoryId);
                } else {
                    LOGGER.error("Id was not defined for current call_history!");
                }
            }
            LOGGER.info("CURRENTCALLHISTORY EQUALS AND YOU MUST SEE "+currentCallHistoryId);
        } catch (SQLException e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    public void addClientAnswerToCallHistory(String columnName, String answer) {
        try (Connection connection = companyDataSource.getConnection();
             PreparedStatement st = connection.prepareStatement("UPDATE call_history SET " + columnName + " = ? " + "WHERE id=?")) {
            st.setString(1, answer);
            st.setLong(2, currentCallHistoryId);
            st.executeUpdate();
        } catch (SQLException e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    public Order findOrderByNumber(String phoneNumber) {
        try (Connection connection = companyDataSource.getConnection();
             PreparedStatement st =
                     connection.prepareStatement("SELECT * FROM orders WHERE phone_number = ?")) {
            st.setString(1, phoneNumber);
            try (ResultSet set = st.executeQuery()){
                if (set.next()) {
                    Order order = new Order();
                    order.setId(set.getInt("id"));
                    order.setPhone_number(set.getString("phone"));
                    order.setCreated(set.getDate("create_date"));
                    order.setArchive(set.getBoolean("archive"));
                    order.setTest(set.getBoolean("test"));
                    return order;
                }
            }
        } catch (SQLException e) {
            LOGGER.error(e.getMessage(), e);
        }
        LOGGER.info("Order is null!");
        return null;
    }
}
