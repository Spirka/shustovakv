package local.work.vxml.company.dialog.calculate;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BinaryOperator;

public class SimpleCalculate {

    /**
     * Map for saving result.
     */
    private Map<String, BinaryOperator<Float>> resultMap = new HashMap<>();

    private static SimpleCalculate instance;

    private SimpleCalculate() {
        this.resultMap.put("сложение", (x, y) -> x + y);
        this.resultMap.put("вычитание", (x, y) -> x - y);
        this.resultMap.put("деление", (x, y) -> x / y);
        this.resultMap.put("умножение", (x, y) -> x * y);
    }

    /**
     * @return create SimpleCalculate
     */
    public static SimpleCalculate getInstance() {
        if (instance == null) {
            instance = new SimpleCalculate();
        }
        return instance;
    }

    public Float executeOperations(String operation, Float first, Float second) {
       return resultMap.get(operation).apply(first, second);
    }
}
