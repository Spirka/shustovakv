package local.work.vxml.company.dialog.models;

import java.time.Instant;
import java.util.Date;

/**
 * Класс для объекта, описывающего запись в таблице orders.
 *
 * @author Kseniya Dergunova.
 * @see Order#id
 */
public class Order {
    /**
     * id таблицы orders autoincrement.
     */
    private int id;

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    /**
     * client's name.
     */
    private String name;
    /**
     * phone_number.
     */
    private String phone_number;
    /**
     * create date and time.
     */
    private Date created;
    /**
     * если true  то мы в любом случае будем звонить клиенту
     * в незвависимости звонили мы ему уже или нет используется ля тестов
     */
    private boolean archive;
    /**
     *  тестовый звонок или нет
     * @return
     */
    private boolean test;

    public boolean isArchive() {
        return archive;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public void setArchive(boolean archive) {
        this.archive = archive;
    }

    public boolean isTest() {
        return this.test;
    }

    public void setTest(boolean test) {
        this.test = test;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", phone_number='" + phone_number + '\'' +
                ", created=" + created +
                ", archive=" + archive +
                ", test=" + test +
                '}';
    }

}
