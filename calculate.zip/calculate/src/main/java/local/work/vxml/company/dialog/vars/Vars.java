package local.work.vxml.company.dialog.vars;

import local.work.vxml.base.vars.StandartDialogVarsVars;

public class Vars {
    //hello
    public static final StandartDialogVarsVars HELLO = new StandartDialogVarsVars("hello", "field1");
    //cantalk
    public static final StandartDialogVarsVars CAN_YOU_SPEAK = new StandartDialogVarsVars("cantalk", "field1");
    //bye
    public static final StandartDialogVarsVars BYE = new StandartDialogVarsVars("bye", "field1");
    //numberOne
    public static final StandartDialogVarsVars NUMBER_ONE = new StandartDialogVarsVars("numberOne", "field1");
    //numberTwo
    public static final StandartDialogVarsVars NUMBER_TWO = new StandartDialogVarsVars("numberTwo", "field1");
    //chooseOperation
    public static final StandartDialogVarsVars OPERATION = new StandartDialogVarsVars("operation", "field1");
    public static final StandartDialogVarsVars RESULT = new StandartDialogVarsVars("result", "field1");
    /**
     * saveHistory Для хранение в сессии первого числа
     */
    public static final String SESSION_VAR_NUMBER_ONE = "numberOne";
    /**
     * save_history Для хранение в сессии второго числа
     */
    public static final String SESSION_VAR_NUMBER_TWO = "numberTwo";
    /**
     * Константа для вычисленного значения, устанавливается как параметр в диалог result.
     */
    public static final String PARAM_TOTAL = "total";
    /**
     * Для выбора логики прощания
     */
    public static final class BYE_PROMPTS {
        public static final String BYE = "bye";
        public static final String BYE_NOTCALLLATER = "byenotcalllater";
        public static final String BYE_CALLLATER = "byecalllater";
        public static final String BYE_ERROR = "byeerror";
    }
    /**
     * Для выбора логики диалога can_talk (перезвонить или нет);
     */
    public static final class CANTALK {
        public static final String YES = "yes";
        public static final String NO = "no";
        public static final String CALLBACK = "callbacklater";
    }
}
