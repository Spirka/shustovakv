package local.work.vxml.company.dialog;

import local.work.vxml.base.AppGeneralException;
import local.work.vxml.base.impl.shared.BaseAppLogic;
import local.work.vxml.base.interfaces.IDialog;
import local.work.vxml.base.interfaces.IDialogResult;
import local.work.vxml.base.interfaces.IDialogResultSlot;
import local.work.vxml.base.interfaces.ISessionService;
import local.work.vxml.company.dialog.calculate.SimpleCalculate;
import local.work.vxml.company.dialog.models.Order;
import local.work.vxml.company.dialog.service.CalculateService;
import local.work.vxml.company.dialog.vars.Vars;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

public class AppLogic extends BaseAppLogic {
    private final static Logger LOGGER = Logger.getLogger(AppLogic.class);

    @Autowired
    private CalculateService calculateService;

    /**
     * Ищет совпадения в таблице orders, если номер телефона есть, то возвращаем объект Order и сохраняем его id в таблицу call_history.
     *
     * @return возвращает найденный диалог hello
     * @throws AppGeneralException
     */
    @Override
    public IDialog getStartDialog() throws AppGeneralException {
        String phoneNumber = sessionService.getAsString(ISessionService.ANI_PARAM, null);
        if (phoneNumber != null) {
            Order order = calculateService.findOrderByNumber(phoneNumber);
            if ((order != null) && (order.isTest() || !order.isArchive())) {
                calculateService.addOrderToCallHistoryTable(order.getId());
                return lookupDialog(Vars.HELLO.NAME);
            } else {
                LOGGER.error(String.format("Order was not found by %s", phoneNumber));
            }
        } else {
            LOGGER.error("phone not defined!");
        }
        return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE_ERROR),DISCONNECT_REASONS.GOODEND.name());
    }

    @Override
    public IDialog errorHandler(IDialog iDialog, IDialogResult iDialogResult) throws AppGeneralException {
        return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE_ERROR),DISCONNECT_REASONS.GOODEND.name());
    }

    /**
     * Переопределенный метод поиска следующего диалога, нужен для обработки глобальных команд
     *
     * @param currentDialog текущий диалог
     * @param result        ответ от глобального диалога
     * @return {перенаправление на найденный диалог}
     * @throws AppGeneralException возмоное исключение
     */
    @Override
    public IDialog getNextHandler(IDialog currentDialog, IDialogResult result) throws AppGeneralException {
        if (result.getNbest().size() > 0) {
            for (IDialogResultSlot slot : result.getNbest().get(0).getSlots()) {
                switch (slot.getValue()) {
                    case "global_repeat":
                        return currentDialog;
                    case "operator":
                        return  doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE), DISCONNECT_REASONS.GOODEND.name());

                }
            }
        }
        return this.notProcessed();
    }

    /**
     * Приветствие, переход к следующему диалогу (can_talk).
     *
     * @param result диалог приветствия
     * @return переход к новому диалогу
     * @throws AppGeneralException возможные исключения
     */
    public IDialog hello(IDialogResult result) throws AppGeneralException {
        if (sessionService.getAsString(ISessionService.CALLID_PARAM) != null) {
            calculateService.addClientAnswerToCallHistory("callid", sessionService.getAsString(ISessionService.CALLID_PARAM));
        }
        if (result.getType() == IDialogResult.Type.NOINPUT) {
            calculateService.addClientAnswerToCallHistory(Vars.HELLO.NAME, result.getType().name());
            return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE), DISCONNECT_REASONS.NOINPUT.name());
        } else {
            String rule = result.getNbest().get(0).getSlot(Vars.HELLO.FIELD1.SLOTS.RULE).getValue();
            calculateService.addClientAnswerToCallHistory(Vars.HELLO.NAME, rule);
            return lookupDialog(Vars.CAN_YOU_SPEAK.NAME);
        }
    }

    public IDialog cantalk(IDialogResult result) throws AppGeneralException {
        if (result.getType() == IDialogResult.Type.NOINPUT) {
            calculateService.addClientAnswerToCallHistory(Vars.CAN_YOU_SPEAK.NAME, result.getType().name());
            return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE), DISCONNECT_REASONS.NOINPUT.name());
        } else if (result.getType() == IDialogResult.Type.NOMATCH) {
            calculateService.addClientAnswerToCallHistory(Vars.CAN_YOU_SPEAK.NAME, result.getType().name());
            return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE), DISCONNECT_REASONS.NOMATCH.name());
        } else {
            String rule = result.getNbest().get(0).getSlot(Vars.CAN_YOU_SPEAK.FIELD1.SLOTS.RULE).getValue();
            calculateService.addClientAnswerToCallHistory(Vars.CAN_YOU_SPEAK.NAME, rule);
            String reasonForByeIfNeeded = null;
            if (Vars.CANTALK.YES.equals(rule)) {
                return lookupDialog(Vars.NUMBER_ONE.NAME);
            } else if (Vars.CANTALK.NO.equals(rule)) {
                reasonForByeIfNeeded = Vars.BYE_PROMPTS.BYE_NOTCALLLATER;
            } else if (Vars.CANTALK.CALLBACK.equals(rule)) {
                reasonForByeIfNeeded = Vars.BYE_PROMPTS.BYE_CALLLATER;
            }
            return doEnd(getByeDialog(reasonForByeIfNeeded), DISCONNECT_REASONS.GOODEND.name());
        }
    }

    public IDialog numberOne(IDialogResult result) throws AppGeneralException {
        if (result.getType() == IDialogResult.Type.NOINPUT) {
            calculateService.addClientAnswerToCallHistory(Vars.NUMBER_ONE.NAME, result.getType().name());
            return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE), DISCONNECT_REASONS.NOINPUT.name());
        } else if (result.getType() == IDialogResult.Type.NOMATCH) {
            calculateService.addClientAnswerToCallHistory(Vars.NUMBER_ONE.NAME, result.getType().name());
            return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE), DISCONNECT_REASONS.NOMATCH.name());
        } else {
            String rule = result.getNbest().get(0).getSlot(Vars.NUMBER_ONE.FIELD1.SLOTS.RULE).getValue();
            calculateService.addClientAnswerToCallHistory(Vars.NUMBER_ONE.NAME, rule);
            this.sessionService.put(Vars.SESSION_VAR_NUMBER_ONE, rule);
            return lookupDialog(Vars.NUMBER_TWO.NAME);
        }
    }

    public IDialog numberTwo(IDialogResult result) throws AppGeneralException {
        if (result.getType() == IDialogResult.Type.NOINPUT) {
            calculateService.addClientAnswerToCallHistory(Vars.NUMBER_TWO.NAME, result.getType().name());
            return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE), DISCONNECT_REASONS.NOINPUT.name());
        } else if (result.getType() == IDialogResult.Type.NOMATCH) {
            calculateService.addClientAnswerToCallHistory(Vars.NUMBER_TWO.NAME, result.getType().name());
            return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE), DISCONNECT_REASONS.NOMATCH.name());
        } else {
            String rule = result.getNbest().get(0).getSlot(Vars.NUMBER_TWO.FIELD1.SLOTS.RULE).getValue();
            calculateService.addClientAnswerToCallHistory(Vars.NUMBER_TWO.NAME, rule);
            this.sessionService.put(Vars.SESSION_VAR_NUMBER_TWO, rule);
            return lookupDialog(Vars.OPERATION.NAME);
        }
    }

    public IDialog operation(IDialogResult result) throws AppGeneralException {
        if (result.getType() == IDialogResult.Type.NOINPUT) {
            calculateService.addClientAnswerToCallHistory(Vars.OPERATION.NAME, result.getType().name());
            return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE), DISCONNECT_REASONS.NOINPUT.name());
        } else if (result.getType() == IDialogResult.Type.NOMATCH) {
            calculateService.addClientAnswerToCallHistory(Vars.OPERATION.NAME, result.getType().name());
            return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE), DISCONNECT_REASONS.NOMATCH.name());
        } else {
            String rule = result.getNbest().get(0).getSlot(Vars.OPERATION.FIELD1.SLOTS.RULE).getValue();
            calculateService.addClientAnswerToCallHistory(Vars.OPERATION.NAME, rule);
            IDialog resultDialog = lookupDialog(Vars.RESULT.NAME);
            //PromptSet добавляем, чтобы потом определить, какая операция будет выполняться
            resultDialog.getInputParams().add("prompt_set", rule);
            //Результат арифметической операции добавляем:
            resultDialog.getInputParams().addFloat(Vars.PARAM_TOTAL,
                    (float) SimpleCalculate.getInstance().executeOperations(rule,
                            this.sessionService.getAsFloat(Vars.SESSION_VAR_NUMBER_ONE),
                            this.sessionService.getAsFloat(Vars.SESSION_VAR_NUMBER_TWO)));
            return resultDialog;
        }
    }

    public IDialog result(IDialogResult result) throws AppGeneralException {
        if (result.getType() == IDialogResult.Type.NOINPUT) {
            calculateService.addClientAnswerToCallHistory(Vars.RESULT.NAME, result.getType().name());
            return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE), DISCONNECT_REASONS.NOINPUT.name());
        } else if (result.getType() == IDialogResult.Type.NOMATCH) {
            calculateService.addClientAnswerToCallHistory(Vars.RESULT.NAME, result.getType().name());
            return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE), DISCONNECT_REASONS.NOMATCH.name());
        } else {
            String rule = result.getNbest().get(0).getSlot(Vars.OPERATION.FIELD1.SLOTS.RULE).getValue();
            calculateService.addClientAnswerToCallHistory(Vars.OPERATION.NAME, rule);
            if (rule.equals("result_no")) {
                return doEnd(getByeDialog(Vars.BYE_PROMPTS.BYE), DISCONNECT_REASONS.GOODEND.name());
            }
            return lookupDialog(Vars.NUMBER_ONE.NAME);
        }
    }

    private IDialog getByeDialog(String idPromSet) throws AppGeneralException {
        IDialog bye = lookupDialog(Vars.BYE.NAME);
        bye.getInputParams().add("prompt_set", idPromSet);
        return bye;
    }
}
