package local.work.vxml.company.dialog.dialogs;

import local.work.vxml.base.AppGeneralException;
import local.work.vxml.base.impl.shared.BaseFormDialog;
import local.work.vxml.base.interfaces.IField;
import local.work.vxml.base.interfaces.IPromptList;
import local.work.vxml.base.interfaces.IPromptSet;
import local.work.vxml.base.interfaces.ISessionService;
import local.work.vxml.company.dialog.vars.Vars;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;

/**
 * динамически диалог ответа
 */
public class ResultDialog extends BaseFormDialog {
    @Autowired
    private ISessionService sessionService;
    private final HashMap<String, String> operation = new HashMap<>();

    public ResultDialog() {
        this.operation.put("addition", "сложения");
        this.operation.put("subtraction", "вычитания");
        this.operation.put("multiplication", "умножения");
        this.operation.put("division", "деления");
    }

    /**
     * Собираем форму для диалога result.
     *
     * @return форма диалога result для vxml.
     * @throws AppGeneralException бросают методы get/setPromptSet, get/setPropertySet, get/setGrammarSet.
     */
    public String render() throws AppGeneralException {
        // создает новое поле для диалога (тэг в vxml)
        IField field = this.formService.newField(Vars.RESULT.FIELD1.NAME);

        // получил id блока в prompt_set в файле prompts\result.xml
        String prompt = this.getInputParams().get("prompt_set", Vars.RESULT.FIELD1.SETTING);

        // Записываем в промт значение тэга по id = prompt
        // Например, для вычетания это будет "Результат выполнения операции вычетание:"
        field.setPromptSetById(prompt);
        IPromptSet promptSet = field.getPromptSet();

        // тэги item внутри взятого prompt_set'а
        IPromptList prompts = promptSet.getPrompts();
        // добавляем динамический item
//        prompts.addDynamic(Constants.PARAM__TOTAL, getInputParams().getAsFloat(Constants.PARAM__TOTAL) + ".wav",
//                "" + getInputParams().getAsFloat(Constants.PARAM__TOTAL));
        prompts.addDynamic(Vars.PARAM_TOTAL, String.valueOf(getInputParams().getAsFloat(Vars.PARAM_TOTAL)));
        field.setPropertySetById(Vars.RESULT.FIELD1.SETTING);
        field.setGrammarSetById(Vars.RESULT.FIELD1.SETTING);

        // добавляем поле на форму
        this.form.addField(field);
        this.form.setPropertySetById(Vars.RESULT.NAME);
        return this.form.render();
    }
}
